var ip = '192.168.1.199:9200';
var contextLength = 50;